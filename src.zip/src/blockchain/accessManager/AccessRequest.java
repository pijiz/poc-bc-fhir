/**
 * 
 */
package blockchain.accessManager;

import java.security.PrivateKey;

import blockchain.core.SharedResource;

/**
 * @author pierre-jean.breton
 *
 */
public class AccessRequest {
	
//	// check if one is allowed to access a resource
//	public boolean isGranted(PrivateKey privateKey, SharedResource sharedResource) {
//		
//	}
//
//    //returns balance and stores the UTXO's owned by this wallet in this.UTXOs
//   	public float getBalance() {
//   		float total = 0;	
//           for (Map.Entry<String, TransactionOutput> item: App.UTXOs.entrySet()){
//           	TransactionOutput UTXO = item.getValue();
//               if(UTXO.isMine(publicKey)) { //if output belongs to me ( if coins belong to me )
//               	UTXOs.put(UTXO.id,UTXO); //add it to our list of unspent transactions.
//               	total += UTXO.value ; 
//               }
//           }  
//   		return total;
//   	}
	
}
